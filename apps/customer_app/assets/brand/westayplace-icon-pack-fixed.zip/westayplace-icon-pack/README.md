# Westayplace icon pack

The original generated artwork is preserved in original/. All exported images retain the opaque navy background and square edges; the OS applies its own icon mask.

## Flutter (recommended)
1. Copy flutter/assets/icons/westayplace-icon.png into your app at assets/icons/westayplace-icon.png.
2. Add flutter_launcher_icons to your dev dependencies using `flutter pub add --dev flutter_launcher_icons`.
3. Copy flutter/flutter_launcher_icons.yaml to the app root.
4. Run `dart run flutter_launcher_icons` from the app root.

Do not replace your entire pubspec.yaml. The supplied Android mipmap folders and iOS AppIcon.appiconset are also available for manual installation. Back up existing icon assets first. No separate Android adaptive foreground is included; these are opaque launcher assets.

## Web
Copy web/ assets into your public directory and use head-snippet.html as the favicon setup reference. Flutter Web can use the 192 and 512 PNGs with its existing manifest. Merge manifest settings with your app rather than overwriting app-specific fields.

## Formats
PNG (256, 512, 1024), JPG, WebP, multi-size ICO, and the original 1254-pixel PNG. These are raster exports, not editable SVG/vector artwork. All sizes derive from the same original without redesigning it.
